import numpy as np
import operator
from os import listdir
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

font_set= fm.FontProperties(fname='C:/Windows/Fonts/msyh.ttc', size=14)

def classify0(inX, dataSet, labels, k):
    # 获取训练集的行数
    dataSetsize = dataSet.shape[0]
    # 矩阵相减
    diffMat = np.tile(inX, (dataSetsize, 1)) - dataSet
    # 平方
    sqDiffMat = diffMat ** 2
    # 平方后的数据相加
    sqDistances = sqDiffMat.sum(1)
    # 开平方，得到距离
    distances = sqDistances ** 0.5
    # 获取distances中元素从小到大后索引值
    sortedDistIndices = distances.argsort()
    # 初始化记录类别数的字典
    classCount = {}
    # 计算前k个距离的类别个数
    for i in range(k):
        # 取出前k个元素的类别
        voteIlabel = labels[sortedDistIndices[i]]
        # 计算类别次数
        classCount[voteIlabel] = classCount.get(voteIlabel, 0) + 1
    # 按照值降序排列
    sortedClassCount = sorted(classCount.items(), key=operator.itemgetter(1), reverse=True)
    # 返回次数最多的类别
    return sortedClassCount[0][0]


'''
函数说明：将32x32的二进制图像转化为1x1024向量
参数：filename----文件名
'''


def img2vector(filename):
    # 初始化1x1024向量
    returnVect = np.zeros((1, 1024))
    # 打开文件
    file = open(filename)
    # 按行读取
    for i in range(32):
        # 读取一行
        lineStr = file.readline()
        # 将每一行数据一次存放到returnVect
        for j in range(32):
            returnVect[0, i * 32 + j] = int(lineStr[j])
    # 返回转换后的1x1024向量
    return returnVect


'''
函数说明：手写数字分类测试
'''


def handwriteClassTest():
    # 初始化训练集labels
    hwLabels = []
    # 获取训练集文件下的文件
    trainingFileList = listdir('trainingDigits')
    # 获得文件个数
    m = len(trainingFileList)
    # 初始化训练集矩阵
    trainingMat = np.zeros((m, 1024))
    # 从文件中解析类别
    for i in range(m):
        # 获得文件名字
        fileNameStr = trainingFileList[i]
        # 获得分类的数字
        classNumber = int(fileNameStr.split('_')[0])
        # 将获得类别添加
        hwLabels.append(classNumber)
        # 将文件的数据存储到训练集矩阵
        trainingMat[i, :] = img2vector('trainingDigits/%s' % (fileNameStr))
    # 获得测试集文件下的文件名
    testFileList = listdir('testDigits')
    # 测试集数据的数量
    mTest = len(testFileList)
    # 错误计数
    errorCount = 0.0
    # 从文件中解析测试集的类别并进行分类
    for i in range(mTest):
        # 获得文件名
        fileNameStr = testFileList[i]
        # 获得类别数字
        classNumber = int(fileNameStr.split('_')[0])
        # 获得测试的1x1024向量，用于训练
        vectorUnderTest = img2vector('testDigits/%s' % (fileNameStr))
        # 获得预测结果
        classifierReult = classify0(vectorUnderTest, trainingMat, hwLabels, 3)
        #print('预测结果%d 真实结果%d' % (classifierReult, classNumber))
        #打印样例
        f=open('testDigits/%s' % (fileNameStr))
        px=[]
        py=[]
        for i in range(32):
            lineStr = f.readline()
            for j,x in enumerate(lineStr):
                if x=='1':
                    px.append(32-i)
                    py.append(j)
        plt.figure(figsize=(3, 6))
        plt.scatter(py,px,color='#000000',s=90,marker=',' )
        plt.title('预测结果%d 真实结果%d' % (classifierReult, classNumber),fontproperties=font_set)
        plt.show()

        if classifierReult != classNumber:
            errorCount += 1.0
    print('总共错了%d个数据\n错误率为%f%%' % (errorCount, errorCount / mTest * 100))


'''
函数说明：main函数
'''

if __name__ == '__main__':
    handwriteClassTest()